import 'package:get/get.dart';

import 'package:gcms/app/modules/home/controllers/home_controller.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<HomeController>(
      () => HomeController(),fenix: true
    );
  }
}
