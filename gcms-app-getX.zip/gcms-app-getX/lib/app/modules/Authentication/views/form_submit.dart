import 'package:flutter/material.dart';
import 'package:gcms/app/modules/commonWidgets/snackbar.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:get/get_utils/src/extensions/dynamic_extensions.dart';
import 'package:get/get_utils/src/get_utils/get_utils.dart';

final controller = Get.find();

void signupSubmitForm() {
  if (GetUtils.isEmail(controller.signUpEmailController.text)) {
    if (GetUtils!.isBlank!) {
      ShowSnackBar(
        "Password cannot be empty",
        "Please provide a valid password.",
        Colors.red,
      );
    } else {
      if (GetUtils!.isBlank!) {
        ShowSnackBar(
          "Password cannot be empty",
          "Please provide a valid password.",
          Colors.red,
        );
      } else {
        if (controller.signUpPasswordController.text !=
            controller.signUpConfirmPasswordController.text) {
          ShowSnackBar(
            "Password Error",
            "Passwords entered did not match.",
            Colors.red,
          );
        } else {
          if (controller.isProcessing.value == false) {
            controller.register({
              'username': controller.signUpEmailController.text,
              'email': controller.signUpEmailController.text,
              'password': controller.signUpPasswordController.text,
            });
          }
        }
      }
    }
  } else {
    ShowSnackBar(
      "Invalid Email",
      "Please provide a valid email address.",
      Colors.red,
    );
  }
}
