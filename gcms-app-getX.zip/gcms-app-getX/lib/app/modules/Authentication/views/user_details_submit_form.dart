import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';

final controller = Get.find();
final now = DateTime.now();

void userDetailsSubmitForm() {
  controller.validateCreateUserForm();
  controller.createUser({
    'firstname': controller.firstnameController.text,
    'lastname': controller.lastnameController.text,
    'address': controller.addressController.text,
    'gender': controller.genderController.text,
    'hcp': controller.hcpController.text,
    "dob": "2021/03/19",
    "dateJoined": now.toString(),
    "usertypeId": 2,
    'aspnetusersId': controller.storage.read('aspUserID').toString(),
  });
}
