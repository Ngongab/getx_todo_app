import 'package:get/get.dart';

class ResultsScreenController extends GetxController {
  //TODO: Implement ResultsScreenController

  String res = '80.0';
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}
